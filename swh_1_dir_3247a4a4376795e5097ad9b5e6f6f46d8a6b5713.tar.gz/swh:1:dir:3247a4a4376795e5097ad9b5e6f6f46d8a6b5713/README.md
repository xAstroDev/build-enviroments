# build-environments
Dockerfile entries used for building Citra binaries.

https://hub.docker.com/r/citraemu/build-environments/
